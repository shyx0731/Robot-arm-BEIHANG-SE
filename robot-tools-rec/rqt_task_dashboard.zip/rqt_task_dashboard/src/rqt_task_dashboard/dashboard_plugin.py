#!/usr/bin/env python3
import csv
import time
import threading
from dataclasses import dataclass
from typing import List

import cv2
import rospy
import rosservice
from cv_bridge import CvBridge, CvBridgeError
from geometry_msgs.msg import PoseStamped
from python_qt_binding import QtCore, QtGui, QtWidgets
from qt_gui.plugin import Plugin
from sensor_msgs.msg import BatteryState, Image
from std_msgs.msg import String

try:
    import pyqtgraph as pg
except ImportError:  # pragma: no cover - runtime fallback
    pg = None


@dataclass
class TaskItem:
    task_id: str
    status: str
    target: str


class TaskDashboard(Plugin):
    def __init__(self, context):
        super(TaskDashboard, self).__init__(context)
        self.setObjectName("TaskDashboard")

        self._bridge = CvBridge()
        self._lock = threading.Lock()
        self._latest_status = "Idle"
        self._latest_pose = "x=0.00, y=0.00, yaw=0.00"
        self._latest_battery = "N/A"
        self._latest_frame = None
        self._last_frame_ts = 0.0
        self._fps = 0.0
        self._tasks: List[TaskItem] = []
        self._task_counter = 1

        self._task_status_topic = rospy.get_param("~task_status_topic", "/task_status")
        self._robot_pose_topic = rospy.get_param("~robot_pose_topic", "/robot_pose")
        self._battery_topic = rospy.get_param("~battery_state_topic", "/battery_state")
        self._video_topic = rospy.get_param("~video_topic", "/yolo_detector/visualization")
        self._append_task_srv = rospy.get_param("~append_task_service", "/task_manager/append_task")
        self._stats_file = rospy.get_param("~stats_file", "")
        self._video_max_fps = float(rospy.get_param("~video_max_fps", 12.0))

        self._widget = QtWidgets.QWidget()
        self._widget.setWindowTitle("Robot Task Dashboard")
        self._build_ui(self._widget)
        self._apply_theme()
        if context.serial_number() > 1:
            self._widget.setWindowTitle(
                "{} ({})".format(self._widget.windowTitle(), context.serial_number())
            )
        context.add_widget(self._widget)

        self._status_sub = rospy.Subscriber(self._task_status_topic, String, self._on_status, queue_size=10)
        self._pose_sub = rospy.Subscriber(self._robot_pose_topic, PoseStamped, self._on_pose, queue_size=10)
        self._battery_sub = rospy.Subscriber(self._battery_topic, BatteryState, self._on_battery, queue_size=10)
        self._video_sub = rospy.Subscriber(self._video_topic, Image, self._on_video, queue_size=1)

        self._ui_timer = QtCore.QTimer(self._widget)
        self._ui_timer.timeout.connect(self._refresh_ui)
        self._ui_timer.start(100)

        self._stats_timer = QtCore.QTimer(self._widget)
        self._stats_timer.timeout.connect(self._refresh_stats)
        self._stats_timer.start(2000)

    def _build_ui(self, parent):
        root = QtWidgets.QVBoxLayout(parent)
        root.setContentsMargins(12, 12, 12, 12)
        root.setSpacing(10)

        header = QtWidgets.QWidget()
        header_l = QtWidgets.QHBoxLayout(header)
        header_l.setContentsMargins(8, 8, 8, 8)
        header_l.setSpacing(10)
        title = QtWidgets.QLabel("机器人任务可视化面板")
        title.setObjectName("HeaderTitle")
        subtitle = QtWidgets.QLabel("状态 · 任务 · 统计 · 视频")
        subtitle.setObjectName("HeaderSubtitle")
        title_box = QtWidgets.QVBoxLayout()
        title_box.setSpacing(0)
        title_box.addWidget(title)
        title_box.addWidget(subtitle)
        header_l.addLayout(title_box)
        header_l.addStretch(1)

        self.badge_ros = QtWidgets.QLabel("ROS Online")
        self.badge_ros.setObjectName("BadgeOk")
        header_l.addWidget(self.badge_ros)
        root.addWidget(header)

        splitter = QtWidgets.QSplitter(QtCore.Qt.Horizontal)
        splitter.setObjectName("MainSplitter")
        root.addWidget(splitter, stretch=1)

        left = QtWidgets.QWidget()
        left_layout = QtWidgets.QVBoxLayout(left)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(10)
        splitter.addWidget(left)

        right = QtWidgets.QWidget()
        right_layout = QtWidgets.QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(10)
        splitter.addWidget(right)
        splitter.setSizes([560, 560])

        # Status panel
        status_group = QtWidgets.QGroupBox("状态显示")
        status_group.setObjectName("Card")
        sg = QtWidgets.QGridLayout(status_group)
        sg.setContentsMargins(12, 12, 12, 12)
        sg.setHorizontalSpacing(12)
        sg.setVerticalSpacing(10)
        self.lbl_state = QtWidgets.QLabel("Idle")
        self.lbl_state_lamp = QtWidgets.QLabel()
        self.lbl_state_lamp.setFixedSize(16, 16)
        self.lbl_pose = QtWidgets.QLabel("x=0.00, y=0.00, yaw=0.00")
        self.lbl_battery = QtWidgets.QLabel("N/A")
        self.lbl_state.setObjectName("StateText")
        sg.addWidget(QtWidgets.QLabel("机器人状态"), 0, 0)
        state_box = QtWidgets.QHBoxLayout()
        state_box.addWidget(self.lbl_state_lamp)
        state_box.addWidget(self.lbl_state)
        state_box.addStretch(1)
        sg.addLayout(state_box, 0, 1)
        sg.addWidget(QtWidgets.QLabel("位姿"), 1, 0)
        sg.addWidget(self.lbl_pose, 1, 1)
        sg.addWidget(QtWidgets.QLabel("电量"), 2, 0)
        sg.addWidget(self.lbl_battery, 2, 1)
        sg.setColumnStretch(1, 1)
        left_layout.addWidget(status_group)

        # Task panel
        task_group = QtWidgets.QGroupBox("任务管理")
        task_group.setObjectName("Card")
        tg = QtWidgets.QVBoxLayout(task_group)
        tg.setContentsMargins(12, 12, 12, 12)
        tg.setSpacing(10)
        controls = QtWidgets.QHBoxLayout()
        controls.setSpacing(8)
        self.cmb_target = QtWidgets.QComboBox()
        self.cmb_target.addItems(["B", "C"])
        self.cmb_filter = QtWidgets.QComboBox()
        self.cmb_filter.addItems(["全部", "Queued", "Success", "Failed"])
        self.cmb_filter.currentTextChanged.connect(self._apply_task_filter)
        self.btn_add = QtWidgets.QPushButton("添加任务")
        self.btn_add.setObjectName("BtnPrimary")
        self.btn_add.clicked.connect(self._on_add_task_clicked)
        self.btn_clear = QtWidgets.QPushButton("清空任务")
        self.btn_clear.setObjectName("BtnDanger")
        self.btn_clear.clicked.connect(self._on_clear_tasks)
        controls.addWidget(QtWidgets.QLabel("目标区域"))
        controls.addWidget(self.cmb_target)
        controls.addWidget(QtWidgets.QLabel("筛选"))
        controls.addWidget(self.cmb_filter)
        controls.addStretch(1)
        controls.addWidget(self.btn_clear)
        controls.addWidget(self.btn_add)
        tg.addLayout(controls)

        self.task_table = QtWidgets.QTableWidget(0, 3)
        self.task_table.setObjectName("TaskTable")
        self.task_table.setHorizontalHeaderLabels(["ID", "状态", "目标区域"])
        self.task_table.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch)
        self.task_table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.task_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.task_table.setAlternatingRowColors(True)
        self.task_table.verticalHeader().setVisible(False)
        tg.addWidget(self.task_table)
        left_layout.addWidget(task_group)

        # Stats panel
        stats_group = QtWidgets.QGroupBox("任务统计")
        stats_group.setObjectName("Card")
        stg = QtWidgets.QVBoxLayout(stats_group)
        stg.setContentsMargins(12, 12, 12, 12)
        stg.setSpacing(10)
        summary = QtWidgets.QHBoxLayout()
        summary.setSpacing(10)
        self.lbl_total = QtWidgets.QLabel("总任务数: 0")
        self.lbl_success = QtWidgets.QLabel("成功率: 0.00%")
        self.lbl_total.setObjectName("Kpi")
        self.lbl_success.setObjectName("Kpi")
        summary.addWidget(self.lbl_total)
        summary.addWidget(self.lbl_success)
        summary.addStretch(1)
        self.btn_refresh_stats = QtWidgets.QPushButton("刷新统计")
        self.btn_refresh_stats.setObjectName("BtnSecondary")
        self.btn_refresh_stats.clicked.connect(self._refresh_stats)
        summary.addWidget(self.btn_refresh_stats)
        stg.addLayout(summary)

        if pg:
            self.chart = pg.PlotWidget()
            self.chart.setBackground(None)
            self.chart.setLabel("left", "任务数量")
            self.chart.setLabel("bottom", "类别")
            self.chart.showGrid(x=True, y=True, alpha=0.2)
            stg.addWidget(self.chart)
        else:
            self.chart = None
            tip = QtWidgets.QLabel("未安装 pyqtgraph，图表已禁用（不影响其他功能）。")
            tip.setObjectName("Muted")
            stg.addWidget(tip)

        right_layout.addWidget(stats_group, stretch=1)

        # Video panel
        video_group = QtWidgets.QGroupBox("视频流回显")
        video_group.setObjectName("Card")
        vg = QtWidgets.QVBoxLayout(video_group)
        vg.setContentsMargins(12, 12, 12, 12)
        vg.setSpacing(8)
        self.video_label = QtWidgets.QLabel("等待图像流...")
        self.video_label.setAlignment(QtCore.Qt.AlignCenter)
        self.video_label.setMinimumSize(480, 360)
        self.video_label.setObjectName("VideoLabel")
        vg.addWidget(self.video_label)
        foot = QtWidgets.QHBoxLayout()
        self.lbl_video_topic = QtWidgets.QLabel(self._video_topic)
        self.lbl_video_topic.setObjectName("Muted")
        self.lbl_fps = QtWidgets.QLabel("FPS: 0.0")
        self.lbl_fps.setObjectName("Muted")
        foot.addWidget(self.lbl_video_topic)
        foot.addStretch(1)
        foot.addWidget(self.lbl_fps)
        vg.addLayout(foot)
        right_layout.addWidget(video_group, stretch=2)

        left_layout.addStretch(1)
        right_layout.addStretch(1)

    def _apply_theme(self):
        # 统一“卡片式 + 深色主题 + 彩色按钮”外观
        qss = """
        QWidget {
          font-family: "Noto Sans CJK SC","Microsoft YaHei","Ubuntu";
          font-size: 11pt;
          color: #e6e6e6;
          background: #0f172a;
        }
        QGroupBox#Card {
          background: rgba(255,255,255,0.06);
          border: 1px solid rgba(255,255,255,0.10);
          border-radius: 12px;
          margin-top: 12px;
        }
        QGroupBox#Card::title {
          subcontrol-origin: margin;
          left: 12px;
          padding: 0 8px;
          color: #cbd5e1;
          font-weight: 600;
        }
        QLabel#HeaderTitle {
          font-size: 18pt;
          font-weight: 800;
          color: #f8fafc;
        }
        QLabel#HeaderSubtitle {
          color: #94a3b8;
        }
        QLabel#Muted {
          color: #94a3b8;
        }
        QLabel#Kpi {
          font-size: 12pt;
          font-weight: 700;
          color: #f8fafc;
        }
        QLabel#StateText {
          font-size: 18pt;
          font-weight: 800;
          letter-spacing: 0.5px;
        }
        QLabel#BadgeOk {
          padding: 4px 10px;
          border-radius: 999px;
          background: rgba(34,197,94,0.18);
          border: 1px solid rgba(34,197,94,0.35);
          color: #86efac;
          font-weight: 700;
        }
        QLabel#BadgeBad {
          padding: 4px 10px;
          border-radius: 999px;
          background: rgba(239,68,68,0.16);
          border: 1px solid rgba(239,68,68,0.35);
          color: #fecaca;
          font-weight: 700;
        }
        QComboBox {
          background: rgba(255,255,255,0.07);
          border: 1px solid rgba(255,255,255,0.10);
          border-radius: 8px;
          padding: 6px 10px;
        }
        QComboBox::drop-down {
          border: none;
          width: 22px;
        }
        QComboBox::down-arrow {
          image: none;
          border-left: 6px solid transparent;
          border-right: 6px solid transparent;
          border-top: 8px solid #94a3b8;
          margin-right: 10px;
        }
        QPushButton {
          border: 1px solid rgba(255,255,255,0.12);
          border-radius: 10px;
          padding: 8px 14px;
          background: rgba(255,255,255,0.06);
        }
        QPushButton:hover {
          background: rgba(255,255,255,0.10);
        }
        QPushButton:pressed {
          background: rgba(255,255,255,0.14);
        }
        QPushButton#BtnPrimary {
          background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #22c55e, stop:1 #16a34a);
          border: 1px solid rgba(34,197,94,0.55);
          color: #06230f;
          font-weight: 800;
        }
        QPushButton#BtnPrimary:hover {
          background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #34d399, stop:1 #22c55e);
        }
        QPushButton#BtnSecondary {
          background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #60a5fa, stop:1 #3b82f6);
          border: 1px solid rgba(59,130,246,0.55);
          color: #061426;
          font-weight: 800;
        }
        QPushButton#BtnDanger {
          background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #fb7185, stop:1 #ef4444);
          border: 1px solid rgba(239,68,68,0.55);
          color: #2b050a;
          font-weight: 800;
        }
        QTableWidget#TaskTable {
          background: rgba(255,255,255,0.04);
          border: 1px solid rgba(255,255,255,0.10);
          border-radius: 10px;
          gridline-color: rgba(255,255,255,0.10);
        }
        QHeaderView::section {
          background: rgba(148,163,184,0.14);
          color: #e2e8f0;
          padding: 8px;
          border: none;
          font-weight: 800;
        }
        QTableWidget::item {
          padding: 6px;
        }
        QTableWidget::item:selected {
          background: rgba(96,165,250,0.28);
        }
        QLabel#VideoLabel {
          background: #0b1020;
          border: 1px solid rgba(255,255,255,0.10);
          border-radius: 10px;
          color: #94a3b8;
        }
        """
        self._widget.setStyleSheet(qss)

    def _on_status(self, msg):
        with self._lock:
            self._latest_status = msg.data
        self._sync_task_status_from_message(msg.data)

    def _on_pose(self, msg):
        x = msg.pose.position.x
        y = msg.pose.position.y
        z = msg.pose.orientation.z
        w = msg.pose.orientation.w
        yaw = 2.0 * self._safe_atan2(z, w)
        with self._lock:
            self._latest_pose = "x={:.2f}, y={:.2f}, yaw={:.2f}".format(x, y, yaw)

    def _on_battery(self, msg):
        percent = msg.percentage * 100.0 if msg.percentage >= 0.0 else 0.0
        with self._lock:
            self._latest_battery = "{:.2f} V ({:.1f}%)".format(msg.voltage, percent)

    def _on_video(self, msg):
        try:
            now = time.time()
            if self._video_max_fps > 0:
                min_dt = 1.0 / self._video_max_fps
                if self._last_frame_ts > 0 and (now - self._last_frame_ts) < min_dt:
                    return
            if self._last_frame_ts > 0.0:
                dt = now - self._last_frame_ts
                if dt > 0:
                    measured_fps = 1.0 / dt
                    self._fps = 0.8 * self._fps + 0.2 * measured_fps if self._fps > 0 else measured_fps
            self._last_frame_ts = now
            frame = self._bridge.imgmsg_to_cv2(msg, desired_encoding="bgr8")
            with self._lock:
                self._latest_frame = frame
        except CvBridgeError as err:
            rospy.logwarn_throttle(2.0, "Video conversion failed: %s", err)

    def _refresh_ui(self):
        with self._lock:
            status = self._latest_status
            pose = self._latest_pose
            battery = self._latest_battery
            frame = None if self._latest_frame is None else self._latest_frame.copy()

        self.lbl_state.setText(status)
        self.lbl_pose.setText(pose)
        self.lbl_battery.setText(battery)
        self.lbl_fps.setText("FPS: {:.1f}".format(self._fps))

        color = "#22c55e"
        if "error" in status.lower():
            color = "#ef4444"
        elif "moving" in status.lower():
            color = "#f59e0b"
        self.lbl_state.setStyleSheet("color: {};".format(color))
        self.lbl_state_lamp.setStyleSheet(
            "background-color: {}; border-radius: 8px; border: 1px solid #303030;".format(color)
        )

        # ROS 主站连通性小徽章
        try:
            ok = (rospy.get_time() > 0.0) and (rospy.core.is_initialized())
        except Exception:
            ok = False
        self.badge_ros.setText("ROS Online" if ok else "ROS Offline")
        self.badge_ros.setObjectName("BadgeOk" if ok else "BadgeBad")

        if frame is not None:
            self._render_frame(frame)

    def _render_frame(self, frame):
        h, w, _ = frame.shape
        max_w = max(self.video_label.width(), 1)
        max_h = max(self.video_label.height(), 1)
        scale = min(float(max_w) / float(w), float(max_h) / float(h))
        scale = min(scale, 1.0)
        out = cv2.resize(frame, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_AREA)
        rgb = cv2.cvtColor(out, cv2.COLOR_BGR2RGB)
        qimg = QtGui.QImage(rgb.data, rgb.shape[1], rgb.shape[0], rgb.strides[0], QtGui.QImage.Format_RGB888)
        self.video_label.setPixmap(QtGui.QPixmap.fromImage(qimg))

    def _refresh_stats(self):
        total, success = self._load_stats()
        ratio = (float(success) / float(total) * 100.0) if total > 0 else 0.0
        self.lbl_total.setText("总任务数: {}".format(total))
        self.lbl_success.setText("成功率: {:.2f}%".format(ratio))

        if self.chart:
            self.chart.clear()
            bars = pg.BarGraphItem(x=[1, 2], height=[success, max(total - success, 0)], width=0.6, brushes=["#2e7d32", "#c62828"])
            self.chart.addItem(bars)
            axis = self.chart.getAxis("bottom")
            axis.setTicks([[(1, "成功"), (2, "失败")]])

    def _load_stats(self):
        if not self._stats_file:
            total = len(self._tasks)
            success = sum(1 for item in self._tasks if item.status.lower() == "success")
            return total, success

        try:
            total = 0
            success = 0
            with open(self._stats_file, "r", encoding="utf-8") as fp:
                reader = csv.DictReader(fp)
                for row in reader:
                    total += 1
                    if row.get("status", "").lower() == "success":
                        success += 1
            return total, success
        except Exception as err:  # pragma: no cover - runtime dependent
            rospy.logwarn_throttle(5.0, "Load stats file failed: %s", err)
            return len(self._tasks), 0

    def _on_add_task_clicked(self):
        target = self.cmb_target.currentText()
        task_id = "T{:04d}".format(self._task_counter)
        self._task_counter += 1

        ok, message = self._append_task_service(task_id, target)
        status = "Queued" if ok else "Failed"
        self._tasks.append(TaskItem(task_id=task_id, status=status, target=target))
        self._refresh_task_table()
        rospy.loginfo("Append task %s target=%s result=%s msg=%s", task_id, target, ok, message)
        self._refresh_stats()

    def _append_task_to_table(self, task_id, status, target):
        row = self.task_table.rowCount()
        self.task_table.insertRow(row)
        self.task_table.setItem(row, 0, QtWidgets.QTableWidgetItem(task_id))
        self.task_table.setItem(row, 1, QtWidgets.QTableWidgetItem(status))
        self.task_table.setItem(row, 2, QtWidgets.QTableWidgetItem(target))

    def _refresh_task_table(self):
        self.task_table.setRowCount(0)
        current_filter = self.cmb_filter.currentText()
        for item in self._tasks:
            if current_filter != "全部" and item.status != current_filter:
                continue
            self._append_task_to_table(item.task_id, item.status, item.target)

    def _apply_task_filter(self, *_args):
        self._refresh_task_table()

    def _on_clear_tasks(self):
        self._tasks = []
        self.task_table.setRowCount(0)
        self._refresh_stats()

    def _sync_task_status_from_message(self, raw_status: str):
        # 支持两种消息格式：
        # 1) "T0001:Success"
        # 2) "task_id=T0001,status=Success"
        task_id = None
        status = None
        if ":" in raw_status and raw_status.upper().startswith("T"):
            parts = raw_status.split(":", 1)
            task_id = parts[0].strip()
            status = parts[1].strip()
        elif "task_id=" in raw_status and "status=" in raw_status:
            chunks = [chunk.strip() for chunk in raw_status.split(",")]
            kv = {}
            for chunk in chunks:
                if "=" in chunk:
                    k, v = chunk.split("=", 1)
                    kv[k.strip()] = v.strip()
            task_id = kv.get("task_id")
            status = kv.get("status")

        if not task_id or not status:
            return

        normalized = status[:1].upper() + status[1:].lower()
        for item in self._tasks:
            if item.task_id == task_id:
                item.status = normalized
                self._refresh_task_table()
                self._refresh_stats()
                break

    def _append_task_service(self, task_id: str, target: str):
        try:
            rospy.wait_for_service(self._append_task_srv, timeout=1.2)
            srv_class = rosservice.get_service_class_by_name(self._append_task_srv)
            if srv_class is None:
                return False, "service class not found"
            proxy = rospy.ServiceProxy(self._append_task_srv, srv_class)
            req = srv_class._request_class()
            self._fill_request(req, task_id, target)
            resp = proxy(req)
            return self._parse_service_result(resp)
        except Exception as err:
            return False, str(err)

    @staticmethod
    def _fill_request(req, task_id: str, target: str):
        field_names = set(getattr(req, "__slots__", []))
        # NOTE: service fields are project-specific, fill common names when present.
        for candidate, value in (
            ("task_id", task_id),
            ("id", task_id),
            ("target", target),
            ("target_area", target),
            ("zone", target),
            ("area", target),
        ):
            if candidate in field_names:
                setattr(req, candidate, value)

    @staticmethod
    def _parse_service_result(resp):
        for success_key in ("success", "ok", "result"):
            if hasattr(resp, success_key):
                val = getattr(resp, success_key)
                if isinstance(val, bool):
                    msg = getattr(resp, "message", "")
                    return val, msg
        msg = getattr(resp, "message", str(resp))
        return True, msg

    @staticmethod
    def _safe_atan2(z, w):
        import math

        return math.atan2(z, w)

    def shutdown_plugin(self):
        for sub in (self._status_sub, self._pose_sub, self._battery_sub, self._video_sub):
            try:
                sub.unregister()
            except Exception:
                pass
        if self._ui_timer.isActive():
            self._ui_timer.stop()
        if self._stats_timer.isActive():
            self._stats_timer.stop()

