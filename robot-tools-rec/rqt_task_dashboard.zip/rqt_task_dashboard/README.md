# rqt_task_dashboard

一个用于机器人任务监控与调度的人机交互插件，提供以下功能：

- 状态面板：订阅 `/task_status`、`/robot_pose`、`/battery_state`
- 任务管理：调用 `/task_manager/append_task` 下发任务
- 统计图表：显示总任务数、成功率（支持读取 CSV 日志）
- 视频回显：订阅 `/yolo_detector/visualization`

增强版功能（答辩展示友好）：

- 状态灯指示（Idle/Moving/Error 颜色区分）
- 任务筛选（全部/Queued/Success/Failed）
- 任务状态联动（支持 `T0001:Success` 或 `task_id=T0001,status=Success`）
- 视频帧率显示与限帧参数（降低CPU占用）
- 手动刷新统计按钮

## 依赖

- ROS Noetic
- `python_qt_binding`
- `rqt_gui` / `rqt_gui_py`
- `cv_bridge`
- `python3-opencv`
- 可选：`python3-pyqtgraph`

## 编译

```bash
cd ~/catkin_ws
catkin_make
source devel/setup.bash
```

## 运行

```bash
roslaunch rqt_task_dashboard task_dashboard.launch
```

或：

```bash
rqt --standalone rqt_task_dashboard
```

## CSV 统计文件格式（可选）

当设置参数 `stats_file` 时，按 CSV 读取统计数据，至少包含列：

- `status`：`success` 或其他状态

## 可配置参数

- `task_status_topic`：默认 `/task_status`
- `robot_pose_topic`：默认 `/robot_pose`
- `battery_state_topic`：默认 `/battery_state`
- `video_topic`：默认 `/yolo_detector/visualization`
- `append_task_service`：默认 `/task_manager/append_task`
- `stats_file`：默认空（空时使用内存任务统计）
- `video_max_fps`：默认 `12.0`
