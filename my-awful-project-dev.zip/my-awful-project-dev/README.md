# Wall-E 仓库货物分拣码垛机器人

## 项目简介

本项目基于 ROS Noetic + Gazebo，开发一款仓库货物分拣码垛机器人系统。系统通过深度摄像头识别本色纸盒和彩色纸箱两类货物，控制机械臂完成抓取，并分别码垛至不同目标区域（B/C），码垛层数不少于 2 层。

---

## 技术栈

| 类别 | 技术 |
|------|------|
| 操作系统 | Ubuntu 20.04 LTS |
| 机器人操作系统 | ROS Noetic |
| 仿真环境 | Gazebo 9 |
| 视觉算法 | YOLO + OpenCV |
| 点云处理 | PCL |
| 编程语言 | Python 3.6+ / C++11 |
| 版本管理 | Git + GitLab |
| 项目管理 | GitLab Issues / Milestones / Boards |

---

## 分支管理策略

| 分支类型 | 分支名 | 说明 |
|----------|--------|------|
| 常驻分支 | `main` | 稳定版本，仅接受 merge |
| 常驻分支 | `dev` | 日常开发分支 |
| 临时分支 | `feature/xxx` | 新功能开发 |
| 临时分支 | `fix/xxx` | Bug 修复 |

### 分支操作规范

- 每日开发从 `dev` 创建 `feature/xxx` 分支
- 开发完成后提交 Merge Request 到 `dev`
- 经过评审和测试后合并
- 稳定版本从 `dev` 合并到 `main` 并打 tag

---

## 提交规范

### Commit Message 格式


### type 类型

| type | 说明 |
|------|------|
| feat | 新功能 |
| fix | Bug 修复 |
| docs | 文档更新 |
| refactor | 代码重构 |
| test | 测试相关 |
| chore | 构建/工具相关 |

### 关联 Issue

提交时使用 `close #Issue编号` 自动关闭 Issue

**示例：**
feat(robot): 添加物体识别模块 close #9
fix(arm): 修复抓取位置偏移 close #12
docs(readme): 更新分支策略


---

## 目录结构规划

Wall-E/
├── docs/ # 需求文档（SRS、SDD、STD）
├── src/ # ROS 功能包源码
├── scripts/ # 脚本工具
├── config/ # 配置文件
├── launch/ # ROS launch 文件
└── README.md


---

## 持续集成（CI/CD）计划

> 当前处于需求分析阶段，CI/CD 将在代码实现阶段配置

计划配置以下流水线：
- 代码格式检查
- 编译构建验证
- 单元测试自动运行
- 仿真环境集成测试

---

## 相关链接

- 项目地址：http://gitlab.oo.buaa.edu.cn/2026_embedded_software/team7/Wall-E
- GitLab 学习：https://learngitbranching.js.org/?locale=zh_CN

