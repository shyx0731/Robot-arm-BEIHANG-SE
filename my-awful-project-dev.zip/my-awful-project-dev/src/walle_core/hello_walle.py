#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
from geometry_msgs.msg import Twist

def main():
    # 1. 初始化大脑节点，起个名字
    rospy.init_node('hello_walle_node')
    rospy.loginfo("Wall-E 大脑已启动！准备开始转圈...")

    # 2. 创建一个发布者，控制底盘速度。话题叫 /cmd_vel，数据类型是 Twist
    vel_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
    
    # 3. 设置发送频率，每秒发 10 次
    rate = rospy.Rate(10)
    
    # 4. 创建一个速度指令对象
    cmd_msg = Twist()
    cmd_msg.linear.x = 0.0  # 前后速度为 0
    cmd_msg.angular.z = 0.5 # 逆时针旋转速度

    # 5. 循环发送指令，直到你按下 Ctrl+C
    while not rospy.is_shutdown():
        vel_pub.publish(cmd_msg)
        rate.sleep()

if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass
