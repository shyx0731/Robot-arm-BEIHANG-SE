#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
import cv2
import numpy as np
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError

class BoxDetector:
    def __init__(self):
        rospy.init_node('box_detector_node', anonymous=True)
        self.bridge = CvBridge()
        
        # 【注意】这里填入你在仿真环境里用 rqt_image_view 查到的真实相机话题名！
        # 仿真里通常是 /kinect2/qhd/image_color 或者 /camera/rgb/image_raw
        self.image_sub = rospy.Subscriber("/kinect2/hd/image_color_rect", Image, self.image_callback)
        
        rospy.loginfo("视觉识别节点已启动，正在等待相机画面...")

    def image_callback(self, data):
        try:
            # 1. 将 ROS 图像格式转换为 OpenCV 格式
            cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")
        except CvBridgeError as e:
            print(e)
            return

        # 2. 图像处理：寻找蓝色的箱子
        # 将 BGR 图像转换为 HSV 颜色空间（HSV 对光照不敏感，更适合找颜色）
        hsv_image = cv2.cvtColor(cv_image, cv2.COLOR_BGR2HSV)

        # 定义蓝色的 HSV 范围 (你可以根据实际箱子颜色调整这些数值)
        lower_blue = np.array([100, 50, 50])
        upper_blue = np.array([130, 255, 255])

        # 根据阈值构建掩膜（Mask），蓝色的地方变白，其他地方变黑
        mask = cv2.inRange(hsv_image, lower_blue, upper_blue)

        # 寻找图像中的轮廓
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        # 3. 找到最大的轮廓（假设最大的蓝色物体就是我们要抓的箱子）
        if len(contours) > 0:
            largest_contour = max(contours, key=cv2.contourArea)
            area = cv2.contourArea(largest_contour)

            # 过滤掉太小的噪点
            if area > 500: 
                # 获取包围框的坐标
                x, y, w, h = cv2.boundingRect(largest_contour)
                
                # 计算箱子的中心点坐标 (cx, cy)
                cx = x + w // 2
                cy = y + h // 2

                # 在原图上画出绿色的矩形框和红色的中心点
                cv2.rectangle(cv_image, (x, y), (x+w, y+h), (0, 255, 0), 2)
                cv2.circle(cv_image, (cx, cy), 5, (0, 0, 255), -1)
                
                # 打印出箱子在画面中的 2D 坐标（这是为下一步抓取做准备！）
                rospy.loginfo(f"发现箱子！画面坐标: X={cx}, Y={cy}")

        # 4. 显示处理后的画面
        cv2.imshow("Box Detector", cv_image)
        cv2.waitKey(1) # 必须有这句，否则画面会卡死

if __name__ == '__main__':
    try:
        detector = BoxDetector()
        rospy.spin() # 让节点保持运行
    except KeyboardInterrupt:
        print("Shutting down")
        cv2.destroyAllWindows()
